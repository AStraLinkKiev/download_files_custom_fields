<?php
/**
 * @package     pkg_prodfiles
 * @license     GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

class Pkg_ProdfilesInstallerScript
{
	public function postflight($type, $parent)
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->update($db->quoteName('#__extensions'))
			->set($db->quoteName('enabled') . ' = 1')
			->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
			->where($db->quoteName('folder') . ' = ' . $db->quote('jshopping'))
			->where($db->quoteName('element') . ' = ' . $db->quote('prodfiles'));

		$db->setQuery($query)->execute();

		return true;
	}
}
